------------
CASSIC LOCK CYDGET EXTENSION DOCS
------------

------------
What is this?
------------

Hi there, cool that you finally found your way here :)
This is the ClassicLockCydgetExtension Documentation
As you may know, ClassicLockCydget is completely written in HTML, Javascript and Cycript.
So it actually seems obvious if there is a Modification API to make your own ClassicLockScreen Mods.
It is not as hard as you may think! Just try it out and play around with the existing Extensions.
To write your own Extensions you will need at least some HTML and PLIST Knowledge. So lets start!

------------
API
------------

The ClassicLockCydgetExtension-API is very easy to connect to:
Just create a folder with the name of your Extension and place a .html file
with the same name into this direcory. This all goes to:
"/System/Library/LockCydgets/ClassicLock.cydget/ClassicLockExtension/[YourModName]/[YourModName].html"

Next you will have to create a Property List file for preferenceloader.
Put this file into: "/Library/PreferenceLoader/Preferences/"

Now you can fill this Property File just like any other one.
If you want your Extension to load, you will have to set a "PSSwitchCell" with
"<key>defaults</key>" tag to: "<string>org.h6nry.classiclockextension</string>".
You will also have to set your "<key>key</key>" tags up like this: "<string>[YourModName].enable</string>".
Otherwise your Mod can not be loaded. Look at the existing property list(s) in the mentioned folder
to get an example of how to set this all up correctly (Especially look at the last part of org.h6nry.classiclockextension.plist).

Thats it! ClassicLockCydgetExtension will do all the dirty work and you can focus on Modding!
Happy Coding!
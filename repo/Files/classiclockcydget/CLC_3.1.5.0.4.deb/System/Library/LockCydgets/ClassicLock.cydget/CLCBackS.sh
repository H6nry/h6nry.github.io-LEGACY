#!/bin/sh
/usr/bin/cycript -p SpringBoard /System/Library/LockCydgets/ClassicLock.cydget/CLCBack.cy